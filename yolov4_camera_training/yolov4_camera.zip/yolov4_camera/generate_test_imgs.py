import os

image_files = []
os.chdir('/mydrive/KITTI_testing/image_2/')
for filename in os.listdir(os.getcwd()):
    image_files.append("/mydrive/KITTI_testing_camera/" + filename)
os.chdir('/mydrive/yolov4_camera/')
with open("test_imgs.txt", "w") as outfile:
    for image in image_files:
        outfile.write(image)
        outfile.write("\n")
    outfile.close()